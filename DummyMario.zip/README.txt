-- Install, if you don't have it installed: Microsoft Visual C++ Redistributable (x86): 
https://support.microsoft.com/en-us/topic/the-latest-supported-visual-c-downloads-2647da03-1eea-4433-9aff-95f26a218cc0

-- Run DummyMario.exe 
