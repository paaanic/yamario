<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="tiles3" tilewidth="32" tileheight="32" spacing="2" tilecount="2850" columns="75">
 <image source="tileset32.png" width="2566" height="1308"/>
</tileset>
